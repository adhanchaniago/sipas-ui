# Codeigniter 3.1.9 with Sb-Admin template

It's ready to use!

Thanks to :

  - Codeigniter - [https://www.codeigniter.com/](https://www.codeigniter.com/)
  - Xiaoler - [https://github.com/XiaoLer/blade](https://github.com/XiaoLer/blade)
  - Startbootsrap - [https://startbootstrap.com/template-overviews/sb-admin/](https://startbootstrap.com/template-overviews/sb-admin/)
